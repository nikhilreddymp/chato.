﻿namespace ChatoService
{
    public class UserConnection
    {
        public string User { get; set; }
        public string Room { get; set; }
    }
}