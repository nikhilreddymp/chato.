# chato
This is a project that demonstrates a chat app using signalr
